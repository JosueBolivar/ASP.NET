# Kendo UI Core

Shim repository for [Kendo UI Core](http://www.github.com/telerik/kendo-ui-core)

## About Kendo UI Core

Kendo UI is everything you need to build sites and apps with HTML5 & JavaScript & Kendo UI Core is the free and open-source version of Kendo UI that provides access to the web's best UI widgets and key framework features essential for developing great experiences for the web and mobile.

This package provides the basic Kendo UI Core source and distribution files.

[Bower](http://www.bower.io): `kendo-ui-core`